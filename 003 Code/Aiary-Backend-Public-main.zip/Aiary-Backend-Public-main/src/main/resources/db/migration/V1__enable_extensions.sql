-- UUID 생성 함수용 확장
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- (선택) 필요 없지만 쓰고 싶다면
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";